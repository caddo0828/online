INSERT INTO `on_template_p` VALUES (1, '系统管理', 0);
INSERT INTO `on_template_p` VALUES (6, '人员管理', 1);
INSERT INTO `on_template_p` VALUES (7, '人际关系', 1);
