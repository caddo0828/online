INSERT INTO `on_role` VALUES (1, 'admin', 0, '2019-10-23 19:40:59');
INSERT INTO `on_role` VALUES (3, '蜀', 0, '2019-11-17 23:22:03');
INSERT INTO `on_role` VALUES (4, '魏', 0, '2019-11-22 21:18:23');
INSERT INTO `on_role` VALUES (5, '吴', 0, '2019-11-20 20:16:13');
INSERT INTO `on_role` VALUES (7, '群雄', 0, '2019-11-20 20:16:12');
