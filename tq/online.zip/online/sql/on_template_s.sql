INSERT INTO `on_template_s` VALUES (1, '模块管理', '/system/moduleManager', 0, 1);
INSERT INTO `on_template_s` VALUES (2, '考勤', '/sys', 1, 6);
INSERT INTO `on_template_s` VALUES (3, '角色管理', '/system/roles', 0, 1);
INSERT INTO `on_template_s` VALUES (4, '考勤', '/sys', 1, 6);
INSERT INTO `on_template_s` VALUES (5, '用户管理', '/system/userInfo', 0, 1);
INSERT INTO `on_template_s` VALUES (6, '日志查看', '/system/logInfo', 0, 1);
